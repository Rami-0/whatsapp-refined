# WhatsApp Refined

A small, privacy-first Chrome extension that gives WhatsApp Web a calmer, more desktop-friendly layout inspired by Telegram Web.

## What it changes

- Adds a dedicated folder rail that mirrors WhatsApp's native filters and custom lists.
- Lets you move the folder rail to the left, right, or top.
- Offers compact, balanced, and roomy chat-list density.
- Adds clearer active states, rounded search and filter controls, and a subtle chat backdrop.
- Keeps every action native: selecting a folder clicks WhatsApp's own filter control.

## Privacy

The extension has no analytics, no background service, and no network code. It never stores messages, contacts, phone numbers, media, or folder names. It reads only the visible filter controls needed to mirror the folder rail. The only values saved locally are the four UI preferences shown in the popup.

## Install locally

1. Open `chrome://extensions` in Chrome.
2. Enable **Developer mode**.
3. Choose **Load unpacked** and select this folder.
4. Open or refresh [WhatsApp Web](https://web.whatsapp.com/).

Use the extension icon to change the rail position, chat density, chat-list width, or temporarily disable the refinements.

## Development

No build step or dependencies are required.

```sh
npm test
```

WhatsApp Web changes often. This extension intentionally avoids generated class names and prefers stable IDs, ARIA roles, button state, and layout regions.
