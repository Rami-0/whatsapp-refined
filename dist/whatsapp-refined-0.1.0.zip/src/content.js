(function initWhatsAppRefined() {
  "use strict";

  if (window.top !== window || window.__whatsAppRefinedLoaded) return;
  window.__whatsAppRefinedLoaded = true;

  const utils = globalThis.WRUtils;
  const DEFAULTS = Object.freeze({
    enabled: true,
    railPosition: "left",
    density: "balanced",
    sidebarWidth: 500,
    backdrop: true,
    railCollapsed: false
  });

  const ICONS = Object.freeze({
    all: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.2 6.1A3.1 3.1 0 0 1 8.3 3h7.4a3.1 3.1 0 0 1 3.1 3.1v6.2a3.1 3.1 0 0 1-3.1 3.1h-4.5L7 19v-3.6A3.1 3.1 0 0 1 5.2 12.6V6.1Z"/><path d="M9 8.4h6M9 11.4h3.8"/></svg>',
    unread: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v9a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 15.5v-9Z"/><path d="m5 6 7 5 7-5"/><circle cx="18.5" cy="5.5" r="3.2" class="wr-icon-fill"/></svg>',
    favourites: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 2.7 5.5 6 .9-4.35 4.23 1.03 5.98L12 16.8l-5.38 2.81 1.03-5.98L3.3 9.4l6-.9L12 3Z"/></svg>',
    groups: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.3"/><path d="M3.5 19c.3-4 2.3-6 5.5-6s5.2 2 5.5 6M14 14c3.7-.7 6.1 1 6.5 4.5"/></svg>',
    archived: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16v12H4zM3 4h18v4H3z"/><path d="M9 12h6"/></svg>',
    custom: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7.5A2.5 2.5 0 0 1 6.5 5h3l2 2h6A2.5 2.5 0 0 1 20 9.5v8A2.5 2.5 0 0 1 17.5 20h-11A2.5 2.5 0 0 1 4 17.5v-10Z"/></svg>'
  });

  let settings = { ...DEFAULTS };
  let rail = null;
  let folderNav = null;
  let densityButton = null;
  let refreshTimer = null;
  let observer = null;
  let lastSignature = "";

  function safeStorageGet() {
    return new Promise((resolve) => {
      if (!globalThis.chrome?.storage?.local) return resolve(DEFAULTS);
      chrome.storage.local.get(DEFAULTS, (values) => resolve({ ...DEFAULTS, ...values }));
    });
  }

  function safeStorageSet(values) {
    if (globalThis.chrome?.storage?.local) chrome.storage.local.set(values);
  }

  function iconNode(kind, label) {
    const wrap = document.createElement("span");
    wrap.className = `wr-folder-icon wr-folder-icon--${kind}`;
    wrap.innerHTML = ICONS[kind] || ICONS.custom;
    if (kind === "custom") {
      const initial = document.createElement("b");
      initial.textContent = utils.folderInitial(label);
      wrap.append(initial);
    }
    return wrap;
  }

  function createRail() {
    rail = document.createElement("aside");
    rail.id = "wr-folder-rail";
    rail.setAttribute("aria-label", "WhatsApp Refined folders");

    const top = document.createElement("div");
    top.className = "wr-rail-top";

    const brand = document.createElement("button");
    brand.className = "wr-brand";
    brand.type = "button";
    brand.title = "Collapse folder rail";
    brand.setAttribute("aria-label", "Collapse folder rail");
    brand.innerHTML = '<span class="wr-brand-mark"><i></i><i></i><i></i></span><span class="wr-brand-name">Refined</span>';
    brand.addEventListener("click", () => {
      settings.railCollapsed = !settings.railCollapsed;
      applySettings();
      safeStorageSet({ railCollapsed: settings.railCollapsed });
    });
    top.append(brand);

    folderNav = document.createElement("nav");
    folderNav.className = "wr-folder-nav";
    folderNav.setAttribute("aria-label", "Chat folders");

    const bottom = document.createElement("div");
    bottom.className = "wr-rail-bottom";

    densityButton = document.createElement("button");
    densityButton.type = "button";
    densityButton.className = "wr-density-button";
    densityButton.innerHTML = '<span aria-hidden="true"><i></i><i></i><i></i></span><b>Density</b>';
    densityButton.addEventListener("click", () => {
      const modes = ["compact", "balanced", "roomy"];
      settings.density = modes[(modes.indexOf(settings.density) + 1) % modes.length];
      applySettings();
      safeStorageSet({ density: settings.density });
    });
    bottom.append(densityButton);

    rail.append(top, folderNav, bottom);
    document.body.append(rail);
  }

  function extractLabel(element) {
    const label = element.getAttribute("aria-label") || element.innerText || element.textContent || "";
    return label.replace(/\s+/g, " ").trim().slice(0, 48);
  }

  function isChipLike(element, sideRect) {
    if (element.closest("#wr-folder-rail")) return false;
    const label = extractLabel(element);
    if (!label || label.length > 48) return false;

    const rect = element.getBoundingClientRect();
    if (!rect.width || !rect.height || rect.height > 56 || rect.width > 220) return false;
    if (rect.top < sideRect.top || rect.top > sideRect.top + Math.min(280, sideRect.height * 0.32)) return false;

    const kind = utils.folderKind(label);
    const stateful = element.hasAttribute("aria-pressed") || element.hasAttribute("aria-selected") || element.getAttribute("role") === "tab";
    const compactTextControl = rect.width < 190 && rect.height < 48 && label.split(" ").length <= 5;
    const excluded = /new chat|menu|settings|search|status|channel|community|meta ai/i.test(label);
    return !excluded && (kind !== "custom" || stateful || compactTextControl);
  }

  function findFolderControls() {
    const side = document.querySelector("#side") || document.querySelector('[data-testid="chat-list"]')?.closest("section");
    if (!side) return [];
    const sideRect = side.getBoundingClientRect();
    const candidates = Array.from(side.querySelectorAll('button, [role="button"], [role="tab"]'))
      .filter((element) => isChipLike(element, sideRect))
      .map((element) => {
        const label = extractLabel(element);
        const countMatch = label.match(/(?:^|\s)(\d[\d.,KkMm]*)$/);
        const rect = element.getBoundingClientRect();
        return {
          label: countMatch ? label.slice(0, countMatch.index).trim() : label,
          count: countMatch ? countMatch[1] : "",
          element,
          kind: utils.folderKind(label),
          centerY: rect.top + (rect.height / 2)
        };
      });

    const known = candidates.filter((folder) => folder.kind !== "custom");
    if (!known.length) return [];
    const anchorY = known.reduce((sum, folder) => sum + folder.centerY, 0) / known.length;
    const folders = utils.uniqueFolders(candidates.filter((folder) => folder.kind !== "custom" || Math.abs(folder.centerY - anchorY) < 30));
    const hasKnownFolder = folders.some((folder) => folder.kind !== "custom");
    return hasKnownFolder ? folders.slice(0, 12) : [];
  }

  function markNativeStrip(folders) {
    if (folders.length < 2) return;

    let ancestor = folders[0].element.parentElement;
    while (ancestor && !folders.every((folder) => ancestor.contains(folder.element))) ancestor = ancestor.parentElement;
    if (!ancestor || ancestor.id === "side") return;
    const rect = ancestor.getBoundingClientRect();
    if (rect.height > 92) return;

    document.querySelectorAll(".wr-native-filter-strip").forEach((element) => {
      if (element !== ancestor) element.classList.remove("wr-native-filter-strip");
    });
    if (!ancestor.classList.contains("wr-native-filter-strip")) ancestor.classList.add("wr-native-filter-strip");
  }

  function isActive(element) {
    return element.getAttribute("aria-pressed") === "true" ||
      element.getAttribute("aria-selected") === "true" ||
      element.dataset?.active === "true" ||
      /active|selected/.test(element.className || "");
  }

  function renderFolders(folders) {
    if (!folderNav) return;
    const signature = folders.map((folder) => `${folder.label}:${folder.count}:${isActive(folder.element)}`).join("|");
    if (signature === lastSignature) return;
    lastSignature = signature;
    folderNav.replaceChildren();

    folders.forEach((folder, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "wr-folder-button";
      button.dataset.kind = folder.kind;
      button.title = folder.label;
      button.setAttribute("aria-label", folder.count ? `${folder.label}, ${folder.count}` : folder.label);
      button.setAttribute("aria-current", isActive(folder.element) || (!folders.some((item) => isActive(item.element)) && index === 0) ? "page" : "false");

      const label = document.createElement("span");
      label.className = "wr-folder-label";
      label.textContent = folder.label;
      button.append(iconNode(folder.kind, folder.label), label);

      if (folder.count) {
        const badge = document.createElement("span");
        badge.className = "wr-folder-badge";
        badge.textContent = folder.count;
        button.append(badge);
      }

      button.addEventListener("click", () => {
        folder.element.click();
        window.setTimeout(scheduleRefresh, 80);
      });
      folderNav.append(button);
    });
  }

  function applySettings() {
    const root = document.documentElement;
    root.dataset.wrEnabled = String(Boolean(settings.enabled));
    root.dataset.wrPosition = ["left", "right", "top"].includes(settings.railPosition) ? settings.railPosition : DEFAULTS.railPosition;
    root.dataset.wrDensity = ["compact", "balanced", "roomy"].includes(settings.density) ? settings.density : DEFAULTS.density;
    root.dataset.wrBackdrop = String(Boolean(settings.backdrop));
    root.dataset.wrCollapsed = String(Boolean(settings.railCollapsed));
    root.style.setProperty("--wr-sidebar-width", `${Math.min(620, Math.max(380, Number(settings.sidebarWidth) || DEFAULTS.sidebarWidth))}px`);
    if (densityButton) {
      densityButton.title = `Chat density: ${settings.density}. Click to change.`;
      densityButton.setAttribute("aria-label", `Chat density: ${settings.density}. Click to change.`);
    }
  }

  function refresh() {
    refreshTimer = null;
    const folders = findFolderControls();
    const ready = folders.length > 0;
    document.documentElement.dataset.wrReady = String(ready);
    if (!ready) return;
    markNativeStrip(folders);
    renderFolders(folders);
  }

  function scheduleRefresh() {
    if (refreshTimer) return;
    refreshTimer = window.setTimeout(refresh, 220);
  }

  async function start() {
    settings = await safeStorageGet();
    createRail();
    applySettings();
    refresh();

    observer = new MutationObserver(scheduleRefresh);
    observer.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["aria-pressed", "aria-selected", "class"] });

    globalThis.chrome?.storage?.onChanged?.addListener((changes, area) => {
      if (area !== "local") return;
      Object.entries(changes).forEach(([key, change]) => { settings[key] = change.newValue; });
      applySettings();
      scheduleRefresh();
    });
  }

  if (document.body) start();
  else document.addEventListener("DOMContentLoaded", start, { once: true });
})();
