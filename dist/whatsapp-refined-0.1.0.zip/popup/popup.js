(function initPopup() {
  "use strict";

  const DEFAULTS = {
    enabled: true,
    railPosition: "left",
    density: "balanced",
    sidebarWidth: 500,
    backdrop: true
  };

  const enabled = document.querySelector("#enabled");
  const backdrop = document.querySelector("#backdrop");
  const width = document.querySelector("#sidebarWidth");
  const widthValue = document.querySelector("#sidebarWidthValue");

  function updateRange() {
    const progress = ((Number(width.value) - Number(width.min)) / (Number(width.max) - Number(width.min))) * 100;
    width.style.setProperty("--range-progress", `${progress}%`);
    widthValue.textContent = `${width.value} px`;
  }

  function render(values) {
    enabled.checked = Boolean(values.enabled);
    backdrop.checked = Boolean(values.backdrop);
    width.value = String(values.sidebarWidth);
    const positionInput = document.querySelector(`input[name="railPosition"][value="${values.railPosition}"]`);
    const densityInput = document.querySelector(`input[name="density"][value="${values.density}"]`);
    if (positionInput) positionInput.checked = true;
    if (densityInput) densityInput.checked = true;
    document.body.classList.toggle("is-disabled", !enabled.checked);
    updateRange();
  }

  function save(key, value) {
    globalThis.chrome?.storage?.local?.set({ [key]: value });
  }

  if (globalThis.chrome?.storage?.local) chrome.storage.local.get(DEFAULTS, render);
  else render(DEFAULTS);

  enabled.addEventListener("change", () => {
    document.body.classList.toggle("is-disabled", !enabled.checked);
    save("enabled", enabled.checked);
  });

  backdrop.addEventListener("change", () => save("backdrop", backdrop.checked));

  width.addEventListener("input", updateRange);
  width.addEventListener("change", () => save("sidebarWidth", Number(width.value)));

  document.querySelectorAll('input[name="railPosition"]').forEach((input) => {
    input.addEventListener("change", () => save("railPosition", input.value));
  });

  document.querySelectorAll('input[name="density"]').forEach((input) => {
    input.addEventListener("change", () => save("density", input.value));
  });
})();
