(function initWhatsAppRefined() {
  "use strict";

  if (window.top !== window || window.__whatsAppRefinedLoaded) return;
  window.__whatsAppRefinedLoaded = true;

  const utils = globalThis.WRUtils;
  const { DEFAULTS, normalizeSettings } = globalThis.WRSettings;

  const ICONS = Object.freeze({
    all: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 6.5A2.5 2.5 0 0 1 7.5 4h9A2.5 2.5 0 0 1 19 6.5v6A2.5 2.5 0 0 1 16.5 15H11l-4 3v-3.2a2.5 2.5 0 0 1-2-2.3v-6Z"/><path d="M8.5 8.5h7M8.5 11.5h4.5"/></svg>',
    unread: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v10a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 16.5v-10Z"/><path d="m5 7 7 5 7-5"/><circle cx="18" cy="5" r="2.8" class="wr-icon-fill"/></svg>',
    favourites: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 2.7 5.5 6 .9-4.35 4.23 1.03 5.98L12 16.8l-5.38 2.81 1.03-5.98L3.3 9.4l6-.9L12 3Z"/></svg>',
    groups: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="8.5" cy="8" r="3"/><circle cx="17" cy="9" r="2.25"/><path d="M3 19c.35-4 2.2-6 5.5-6s5.15 2 5.5 6M14 14.2c3.6-.65 6 1 6.4 4.3"/></svg>',
    archived: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16v12H4zM3 4h18v4H3z"/><path d="M9 12h6"/></svg>',
    custom: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7.5A2.5 2.5 0 0 1 6.5 5h3l2 2h6A2.5 2.5 0 0 1 20 9.5v8a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5v-10Z"/></svg>',
    lists: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 6h10M5 12h8M5 18h6"/><path d="M18 13v7M14.5 16.5h7"/></svg>',
    settings: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h10M18 7h2M4 17h2M10 17h10M14 4v6M7 14v6"/></svg>',
    privacy: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4.5 6v5.2c0 4.7 3 8.2 7.5 9.8 4.5-1.6 7.5-5.1 7.5-9.8V6L12 3Z"/><path d="m8 12 2.4 2.4L16.5 8"/></svg>'
  });

  let settings = { ...DEFAULTS };
  let rail = null;
  let folderNav = null;
  let launcher = null;
  let drawer = null;
  let refreshTimer = null;
  let observer = null;
  let lastFolderSignature = "";

  function storageGet() {
    return new Promise((resolve) => {
      if (!globalThis.chrome?.storage?.local) return resolve({ ...DEFAULTS });
      chrome.storage.local.get(null, (values) => resolve(normalizeSettings(values)));
    });
  }

  function storageSet(values) {
    if (globalThis.chrome?.storage?.local) chrome.storage.local.set(values);
  }

  function iconMarkup(kind) {
    return ICONS[kind] || ICONS.custom;
  }

  function createButton(className, label, icon) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = className;
    button.title = label;
    button.setAttribute("aria-label", label);
    button.innerHTML = icon;
    return button;
  }

  function toggleDrawer(force) {
    if (!drawer) return;
    const open = typeof force === "boolean" ? force : drawer.getAttribute("aria-hidden") === "true";
    drawer.setAttribute("aria-hidden", String(!open));
    document.documentElement.dataset.wrSettingsOpen = String(open);
    if (launcher) launcher.setAttribute("aria-pressed", String(open));
  }

  function createRail() {
    rail = document.createElement("aside");
    rail.id = "wr-folder-rail";
    rail.setAttribute("aria-label", "Chat folders");

    const railHeader = document.createElement("div");
    railHeader.className = "wr-rail-header";
    const collapse = createButton("wr-rail-collapse", "Collapse folder rail", '<span class="wr-monogram">WR</span>');
    collapse.addEventListener("click", () => {
      settings.railCollapsed = !settings.railCollapsed;
      applySettings();
      storageSet({ railCollapsed: settings.railCollapsed });
    });
    railHeader.append(collapse);

    folderNav = document.createElement("nav");
    folderNav.className = "wr-folder-nav";
    folderNav.setAttribute("aria-label", "WhatsApp chat folders");

    const railFooter = document.createElement("div");
    railFooter.className = "wr-rail-footer";
    const privacy = createButton("wr-rail-action", "Toggle privacy mode", iconMarkup("privacy") + '<span>Privacy</span>');
    privacy.addEventListener("click", () => {
      settings.privacyEnabled = !settings.privacyEnabled;
      applySettings();
      storageSet({ privacyEnabled: settings.privacyEnabled });
    });
    const settingsButton = createButton("wr-rail-action", "Open Refined settings", iconMarkup("settings") + '<span>Settings</span>');
    settingsButton.addEventListener("click", () => toggleDrawer());
    railFooter.append(privacy, settingsButton);

    rail.append(railHeader, folderNav, railFooter);
  }

  function createDrawer() {
    drawer = document.createElement("aside");
    drawer.id = "wr-settings-drawer";
    drawer.setAttribute("aria-label", "WhatsApp Refined settings");
    drawer.setAttribute("aria-hidden", "true");

    const close = createButton("wr-drawer-close", "Close Refined settings", '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 7 10 10M17 7 7 17"/></svg>');
    close.addEventListener("click", () => toggleDrawer(false));

    const frame = document.createElement("iframe");
    frame.className = "wr-settings-frame";
    frame.title = "WhatsApp Refined settings";
    const theme = document.body.classList.contains("dark") ? "dark" : "light";
    const settingsPage = globalThis.chrome?.runtime?.getURL ? chrome.runtime.getURL("popup/popup.html") : "../popup/popup.html";
    frame.src = `${settingsPage}?embedded=1&theme=${theme}`;
    drawer.append(close, frame);
    document.body.append(drawer);
  }

  function createLauncher() {
    launcher = createButton("wr-settings-launcher", "Open WhatsApp Refined settings", iconMarkup("settings"));
    launcher.setAttribute("aria-pressed", "false");
    launcher.addEventListener("click", () => toggleDrawer());
  }

  function ensureUI() {
    const side = document.querySelector("#side");
    if (!side) return null;

    const shell = side.parentElement;
    if (!shell) return null;
    shell.classList.add("wr-chat-shell");
    if (settings.folderLayout === "native" || !document.documentElement.style.getPropertyValue("--wr-native-shell-width")) {
      document.documentElement.style.setProperty("--wr-native-shell-width", `${Math.round(shell.getBoundingClientRect().width)}px`);
    }
    if (!rail) createRail();
    if (rail.parentElement !== shell) shell.append(rail);

    if (!drawer) createDrawer();
    if (!launcher) createLauncher();
    const nativeRail = Array.from(document.querySelectorAll('header[data-testid="chatlist-header"]')).find((header) => header.getBoundingClientRect().width <= 82);
    if (nativeRail) {
      nativeRail.classList.add("wr-native-navigation");
      if (launcher.parentElement !== nativeRail) nativeRail.append(launcher);
    }

    const closeNotification = side.querySelector('button[aria-label="Close"]');
    if (closeNotification) {
      let banner = closeNotification;
      while (banner.parentElement && banner.parentElement !== side) banner = banner.parentElement;
      if (banner.parentElement === side) banner.classList.add("wr-notification-banner");
    }

    syncNativeNavSlots();

    return { side, shell };
  }

  function findNativeNavSlot(button) {
    let slot = button;
    while (slot.parentElement && slot.parentElement.children.length === 1 && !slot.parentElement.matches('[data-testid="navbar-primary-section"]')) {
      slot = slot.parentElement;
    }
    return slot;
  }

  function syncNativeNavSlots() {
    document.querySelectorAll(".wr-hidden-nav-slot").forEach((slot) => slot.classList.remove("wr-hidden-nav-slot"));
    if (!settings.enabled) return;
    [
      ["Meta AI", settings.hideMetaAI],
      ["Channels", settings.hideChannels]
    ].forEach(([label, hidden]) => {
      if (!hidden) return;
      const button = document.querySelector(`button[aria-label="${label}"]`);
      if (button) findNativeNavSlot(button).classList.add("wr-hidden-nav-slot");
    });
  }

  function readFolders(side) {
    const tablist = side.querySelector('[role="tablist"][aria-label="chat-list-filters"]');
    if (!tablist) return [];
    tablist.classList.add("wr-native-filter-strip");

    return utils.uniqueFolders(Array.from(tablist.querySelectorAll('[role="tab"]')).map((element) => {
      const leafTexts = Array.from(element.querySelectorAll("span"))
        .filter((span) => span.children.length === 0 && span.getAttribute("aria-hidden") !== "true")
        .map((span) => span.textContent);
      const rawLabel = (element.getAttribute("aria-label") || element.innerText || element.textContent || "").replace(/\s+/g, " ").trim();
      const parsed = utils.parseFolderTab(leafTexts, rawLabel);
      const label = parsed.action ? "Lists" : parsed.label;
      return {
        label: label.slice(0, 48),
        count: parsed.count,
        kind: parsed.action ? "lists" : utils.folderKind(label),
        action: parsed.action,
        element,
        selected: element.getAttribute("aria-selected") === "true"
      };
    }).filter((folder) => folder.label)).slice(0, 12);
  }

  function folderIcon(folder) {
    const wrap = document.createElement("span");
    wrap.className = `wr-folder-icon wr-folder-icon--${folder.kind}`;
    wrap.innerHTML = iconMarkup(folder.kind);
    if (folder.kind === "custom") {
      const initial = document.createElement("b");
      initial.textContent = utils.folderInitial(folder.label);
      wrap.append(initial);
    }
    return wrap;
  }

  function renderFolders(folders) {
    const signature = folders.map((folder) => `${folder.label}:${folder.count}:${folder.selected}`).join("|");
    if (!folderNav || signature === lastFolderSignature) return;
    lastFolderSignature = signature;
    folderNav.replaceChildren();

    folders.forEach((folder, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "wr-folder-button";
      if (folder.action) button.classList.add("wr-folder-button--action");
      button.title = folder.label;
      button.setAttribute("aria-label", folder.action ? "Open lists menu" : folder.count ? `${folder.label}, ${folder.count} unread` : folder.label);
      button.setAttribute("aria-current", !folder.action && (folder.selected || (!folders.some((item) => item.selected) && index === 0)) ? "page" : "false");

      const label = document.createElement("span");
      label.className = "wr-folder-label";
      label.textContent = folder.label;
      button.append(folderIcon(folder), label);

      if (folder.count) {
        const badge = document.createElement("span");
        badge.className = "wr-folder-badge";
        badge.textContent = folder.count;
        button.append(badge);
      }

      button.addEventListener("click", () => {
        folder.element.click();
        window.setTimeout(scheduleRefresh, 80);
      });
      folderNav.append(button);
    });
  }

  function applySettings() {
    settings = normalizeSettings(settings);
    const root = document.documentElement;
    const attributes = {
      wrEnabled: settings.enabled,
      wrFolderLayout: settings.folderLayout,
      wrCollapsed: settings.railCollapsed,
      wrCustomWidth: settings.customSidebarWidth,
      wrRowStyle: settings.rowStyle,
      wrShowPreviews: settings.showPreviews,
      wrHideNotification: settings.hideNotificationBanner,
      wrHideMetaAi: settings.hideMetaAI,
      wrHideChannels: settings.hideChannels,
      wrPrivacy: settings.privacyEnabled,
      wrBlurPreviews: settings.blurPreviews,
      wrBlurMessages: settings.blurMessages,
      wrBlurImages: settings.blurImages,
      wrBlurVideos: settings.blurVideos,
      wrBlurNames: settings.blurNames,
      wrBlurAvatars: settings.blurAvatars,
      wrRevealOnHover: settings.revealOnHover
    };
    Object.entries(attributes).forEach(([key, value]) => { root.dataset[key] = String(value); });
    root.style.setProperty("--wr-sidebar-width", `${settings.sidebarWidth}px`);
    root.style.setProperty("--wr-privacy-blur", `${settings.blurStrength}px`);
  }

  function refresh() {
    refreshTimer = null;
    const ui = ensureUI();
    const ready = Boolean(ui);
    document.documentElement.dataset.wrReady = String(ready);
    if (!ui) return;
    renderFolders(readFolders(ui.side));
  }

  function scheduleRefresh() {
    if (refreshTimer) return;
    refreshTimer = window.setTimeout(refresh, 180);
  }

  function onShortcut(event) {
    if (event.altKey && event.shiftKey && event.code === "KeyP") {
      event.preventDefault();
      settings.privacyEnabled = !settings.privacyEnabled;
      applySettings();
      storageSet({ privacyEnabled: settings.privacyEnabled });
    }
    if (event.key === "Escape" && drawer?.getAttribute("aria-hidden") === "false") toggleDrawer(false);
  }

  async function start() {
    settings = await storageGet();
    applySettings();
    refresh();
    document.addEventListener("keydown", onShortcut, true);
    window.addEventListener("resize", scheduleRefresh, { passive: true });

    observer = new MutationObserver(scheduleRefresh);
    observer.observe(document.body, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["aria-selected"]
    });

    globalThis.chrome?.storage?.onChanged?.addListener((changes, area) => {
      if (area !== "local") return;
      Object.entries(changes).forEach(([key, change]) => { settings[key] = change.newValue; });
      applySettings();
      scheduleRefresh();
    });
  }

  if (document.body) start();
  else document.addEventListener("DOMContentLoaded", start, { once: true });
})();
